##_.py
#from . import _shcut, _evlog, _regex, _rxyz
#all = ["init"]
#class init:
#    def __init__(self):
#        self.shcut = _shcut.ushcut
#        self.evlog = _evlog.uevlog
#        self.regex = _regex.rgx
#        self.rxyz = _rxyz._rxyz
#        self.main = main